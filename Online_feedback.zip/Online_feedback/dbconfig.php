<?php
$conn=mysqli_connect("localhost","root","","feedback_system")or die(mysqli_error());
?>